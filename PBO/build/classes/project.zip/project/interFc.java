package project;

public interface interFc {
    public double HitungPajak(double hitungTotal);
}
